package com.example.hitung_bangun_20030008;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etPanjang, etLebar, etTinggi;
    private CheckBox cbPersegiPanjang, cbTabung;
    private Button btnHitung;
    private TextView tvHasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etPanjang = findViewById(R.id.et_panjang);
        etLebar = findViewById(R.id.et_lebar);
        etTinggi = findViewById(R.id.et_tinggi);
        cbPersegiPanjang = findViewById(R.id.cb_persegi_panjang);
        cbTabung = findViewById(R.id.cb_tabung);
        btnHitung = findViewById(R.id.btn_hitung);
        tvHasil = findViewById(R.id.tv_hasil);

        btnHitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double panjang = Double.parseDouble(etPanjang.getText().toString());
                double lebar = Double.parseDouble(etLebar.getText().toString());
                double tinggi = Double.parseDouble(etTinggi.getText().toString());

                if (cbPersegiPanjang.isChecked()) {
                    double luas = panjang * lebar;
                    double keliling = 2 * (panjang + lebar);
                    tvHasil.setText("Luas Persegi Panjang: " + luas + "\nKeliling Persegi Panjang: " + keliling);
                } else if (cbTabung.isChecked()) {
                    double volume = 3.14 * panjang * lebar * tinggi;
                    double keliling = 2 * (3.14 * panjang * (panjang + lebar));
                    tvHasil.setText("Volume Tabung: " + volume + "\nKeliling Tabung: " + keliling);
                }
            }
        });
    }
}